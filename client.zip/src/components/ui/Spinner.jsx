import React from 'react';

/**
 * Spinner Component
 * @param {string} size - 'sm' | 'md' | 'lg'
 * @param {string} className - Additional CSS classes
 */
const Spinner = ({ size = 'md', className = '' }) => {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <div
      className={`
        animate-spin rounded-full border-2 border-border border-t-accent
        ${sizes[size]}
        ${className}
      `}
    />
  );
};

export default Spinner;
