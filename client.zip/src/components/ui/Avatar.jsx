import React from 'react';
import { User } from 'lucide-react';

/**
 * Avatar Component
 * @param {string} src - Image URL
 * @param {string} alt - Alt text
 * @param {string} name - Name for fallback initials
 * @param {string} size - 'sm' | 'md' | 'lg' | 'xl'
 */
const Avatar = ({ src, alt = '', name = '', size = 'md', className = '' }) => {
  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg',
  };

  const getInitials = (name) => {
    if (!name) return '?';
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div
      className={`
        relative inline-flex items-center justify-center
        rounded-full bg-accent/10 text-accent font-medium
        overflow-hidden flex-shrink-0
        ${sizes[size]}
        ${className}
      `}
    >
      {src ? (
        <img
          src={src}
          alt={alt || name}
          className="w-full h-full object-cover"
        />
      ) : (
        <span>{getInitials(name)}</span>
      )}
    </div>
  );
};

export default Avatar;
