import React, { useState } from 'react';

/**
 * Tooltip Component
 * @param {React.ReactNode} children - Trigger element
 * @param {string} content - Tooltip content
 * @param {string} position - 'top' | 'bottom' | 'left' | 'right'
 */
const Tooltip = ({ children, content, position = 'top' }) => {
  const [isVisible, setIsVisible] = useState(false);

  const positions = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
  };

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      {isVisible && content && (
        <div
          className={`
            absolute z-50 px-2 py-1 text-xs font-medium
            bg-bg-secondary text-primary border border-border
            rounded shadow-lg whitespace-nowrap
            ${positions[position]}
          `}
        >
          {content}
          {/* Arrow */}
          <div
            className={`
              absolute w-2 h-2 bg-bg-secondary border-border transform rotate-45
              ${position === 'top' ? '-bottom-1 left-1/2 -translate-x-1/2 border-r border-t' : ''}
              ${position === 'bottom' ? '-top-1 left-1/2 -translate-x-1/2 border-l border-b' : ''}
              ${position === 'left' ? '-right-1 top-1/2 -translate-y-1/2 border-t border-r' : ''}
              ${position === 'right' ? '-left-1 top-1/2 -translate-y-1/2 border-b border-l' : ''}
            `}
          />
        </div>
      )}
    </div>
  );
};

export default Tooltip;
