import React from 'react';

/**
 * Input Component
 * @param {string} label - Label text
 * @param {string} type - Input type (text, email, password, etc.)
 * @param {string} error - Error message to display
 * @param {string} className - Additional CSS classes
 */
const Input = React.forwardRef(({
  label,
  type = 'text',
  error,
  className = '',
  icon,
  ...props
}, ref) => {
  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-semibold text-text-secondary mb-2 ml-1">
          {label}
        </label>
      )}
      <div className="relative group">
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary group-focus-within:text-accent transition-colors duration-200">
            {icon}
          </div>
        )}
        <input
          ref={ref}
          type={type}
          className={`
            w-full px-4 py-3 bg-bg-secondary border rounded-xl
            text-primary placeholder:text-text-secondary/50
            focus:outline-none focus:ring-4 focus:ring-accent/10 focus:border-accent
            transition-all duration-300 shadow-sm
            ${icon ? 'pl-11' : ''}
            ${error ? 'border-danger focus:ring-danger/10 focus:border-danger' : 'border-border'}
            ${className}
          `}
          {...props}
        />
      </div>
      {error && (
        <p className="mt-2 text-sm text-danger font-medium ml-1">{error}</p>
      )}
    </div>
  );
});

Input.displayName = 'Input';

export default Input;
