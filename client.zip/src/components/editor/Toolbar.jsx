import React from 'react';
import { Save, Share2, Download, MoreVertical } from 'lucide-react';
import { motion } from 'framer-motion';

const Toolbar = ({
  title,
  onTitleChange,
  isSaving,
  isSaved,
  onShare,
  onExport,
}) => {
  const [showExportMenu, setShowExportMenu] = React.useState(false);

  return (
    <div className="h-14 bg-bg-card border-b border-border flex items-center justify-between px-4">
      {/* Left: Title */}
      <input
        type="text"
        value={title}
        onChange={(e) => onTitleChange(e.target.value)}
        placeholder="Untitled Note"
        className="flex-1 bg-transparent text-lg font-semibold text-primary placeholder-text-secondary focus:outline-none"
      />

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Save Status */}
        <div className="flex items-center gap-1.5 text-sm text-text-secondary">
          {isSaving ? (
            <>
              <div className="w-4 h-4 animate-spin rounded-full border-2 border-border border-t-accent" />
              <span>Saving...</span>
            </>
          ) : isSaved ? (
            <>
              <Save className="w-4 h-4 text-success" />
              <span>Saved</span>
            </>
          ) : null}
        </div>

        {/* Share Button */}
        <button
          onClick={onShare}
          className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
        >
          <Share2 className="w-4 h-4" />
          <span className="hidden sm:inline">Share</span>
        </button>

        {/* Export Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowExportMenu(!showExportMenu)}
            className="p-2 rounded-lg hover:bg-bg-secondary text-text-secondary hover:text-primary transition-colors"
          >
            <Download className="w-5 h-5" />
          </button>

          {showExportMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowExportMenu(false)}
              />
              <div className="absolute right-0 mt-1 w-40 bg-bg-card border border-border rounded-lg shadow-lg z-20 py-1">
                <button
                  onClick={() => {
                    onExport('pdf');
                    setShowExportMenu(false);
                  }}
                  className="w-full px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-bg-secondary text-left"
                >
                  Export as PDF
                </button>
                <button
                  onClick={() => {
                    onExport('markdown');
                    setShowExportMenu(false);
                  }}
                  className="w-full px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-bg-secondary text-left"
                >
                  Export as Markdown
                </button>
                <button
                  onClick={() => {
                    onExport('json');
                    setShowExportMenu(false);
                  }}
                  className="w-full px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-bg-secondary text-left"
                >
                  Export as JSON
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Toolbar;
