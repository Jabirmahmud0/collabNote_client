import React, { useCallback, useRef } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { useSocket } from '../../hooks/useSocket';

const NoteEditor = ({ content, onChange, readOnly = false }) => {
  const quillRef = useRef(null);
  const { socket, sendNoteChange, sendCursorMove, sendTyping, sendStopTyping } = useSocket();
  const typingTimeoutRef = useRef(null);
  const lastContentRef = useRef(content);

  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ color: [] }, { background: [] }],
      [{ align: [] }],
      ['link', 'image', 'code-block'],
      ['clean'],
    ],
  };

  const formats = [
    'header',
    'bold',
    'italic',
    'underline',
    'strike',
    'list',
    'bullet',
    'color',
    'background',
    'align',
    'link',
    'image',
    'code-block',
  ];

  const handleTextChange = useCallback((delta, oldDelta, source) => {
    // Only send updates from user interaction, not from remote updates
    if (source === 'user') {
      const noteId = window.location.pathname.split('/').pop();
      
      // Send delta to other users via socket
      if (socket) {
        sendNoteChange(noteId, delta);
      }

      // Trigger typing indicator
      if (socket) {
        sendTyping(noteId);
        
        // Clear existing timeout
        if (typingTimeoutRef.current) {
          clearTimeout(typingTimeoutRef.current);
        }
        
        // Set new timeout to stop typing
        typingTimeoutRef.current = setTimeout(() => {
          sendStopTyping(noteId);
        }, 1000);
      }

      // Call parent onChange
      if (onChange) {
        onChange(delta);
      }

      lastContentRef.current = delta;
    }
  }, [socket, onChange, sendNoteChange, sendTyping, sendStopTyping]);

  const handleSelectionChange = useCallback((range, source, editor) => {
    if (range && socket) {
      const noteId = window.location.pathname.split('/').pop();
      sendCursorMove(noteId, range);
    }
  }, [socket, sendCursorMove]);

  return (
    <div className="h-full flex flex-col">
      <ReactQuill
        ref={quillRef}
        theme="snow"
        value={content}
        onChange={handleTextChange}
        onSelectionChange={handleSelectionChange}
        modules={modules}
        formats={formats}
        readOnly={readOnly}
        className="flex-1 flex flex-col bg-bg-primary"
        style={{ flex: 1 }}
      />
      <style jsx>{`
        .quill {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        .quill .ql-container {
          flex: 1;
          overflow: auto;
          font-size: 16px;
          background: var(--bg-primary);
          border: none;
        }
        .quill .ql-toolbar {
          border: none;
          border-bottom: 1px solid var(--border);
          background: var(--bg-secondary);
          position: sticky;
          top: 0;
          z-index: 10;
        }
        .quill .ql-editor {
          color: var(--text-primary);
          padding: 20px;
          min-height: 100%;
        }
        .quill .ql-editor.ql-blank::before {
          color: var(--text-secondary);
        }
        /* Toolbar button styles */
        .ql-toolbar button {
          color: var(--text-secondary);
        }
        .ql-toolbar button:hover,
        .ql-toolbar button.ql-active {
          color: var(--accent);
        }
        .ql-toolbar .ql-stroke {
          stroke: var(--text-secondary);
        }
        .ql-toolbar button:hover .ql-stroke,
        .ql-toolbar button.ql-active .ql-stroke {
          stroke: var(--accent);
        }
        .ql-toolbar .ql-fill {
          fill: var(--text-secondary);
        }
        .ql-toolbar button:hover .ql-fill,
        .ql-toolbar button.ql-active .ql-fill {
          fill: var(--accent);
        }
      `}</style>
    </div>
  );
};

export default NoteEditor;
