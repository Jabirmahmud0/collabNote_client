import React from 'react';
import { Search, X } from 'lucide-react';
import Input from '../ui/Input';

const NoteSearch = ({ value, onChange, onClear }) => {
  return (
    <div className="relative">
      <Input
        type="text"
        placeholder="Search notes by title or content..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        icon={<Search className="w-5 h-5" />}
        className="pr-10"
      />
      {value && (
        <button
          onClick={onClear}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-text-secondary hover:text-primary transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      )}
    </div>
  );
};

export default NoteSearch;
