import React from 'react';
import Badge from '../ui/Badge';

const TagBadge = ({ tag, selected, onClick }) => {
  return (
    <Badge
      variant={selected ? 'accent' : 'default'}
      size="md"
      className={`cursor-pointer transition-colors ${
        selected
          ? 'bg-accent text-white'
          : 'hover:bg-accent/10 hover:text-accent'
      }`}
      onClick={onClick}
    >
      #{tag}
    </Badge>
  );
};

export default TagBadge;
