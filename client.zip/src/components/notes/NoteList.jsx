import React from 'react';
import NoteCard from './NoteCard';
import { motion } from 'framer-motion';

const NoteList = ({
  notes,
  loading,
  onNoteClick,
  onEdit,
  onShare,
  onDelete,
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-accent" />
      </div>
    );
  }

  if (!notes || notes.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center py-12 text-center"
      >
        <div className="w-24 h-24 bg-bg-secondary rounded-full flex items-center justify-center mb-4">
          <svg
            className="w-12 h-12 text-text-secondary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-primary mb-1">No notes yet</h3>
        <p className="text-text-secondary">
          Create your first note to get started
        </p>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
      {notes.map((note) => (
        <NoteCard
          key={note._id}
          note={note}
          onClick={() => onNoteClick(note._id)}
          onEdit={onEdit}
          onShare={onShare}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
};

export default NoteList;
