import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { MoreVertical, Edit2, Trash2, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';
import Avatar from '../ui/Avatar';
import Badge from '../ui/Badge';

const NoteCard = ({ note, onClick, onEdit, onShare, onDelete }) => {
  const [showMenu, setShowMenu] = React.useState(false);

  const excerpt = note.excerpt || (() => {
    if (!note.content?.ops) return 'No content';
    const text = note.content.ops
      .filter((op) => typeof op.insert === 'string')
      .map((op) => op.insert)
      .join(' ')
      .slice(0, 100);
    return text + (text.length >= 100 ? '...' : '');
  })();

  const collaborators = note.collaborators || [];
  const tags = note.tags || [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-bg-card border border-border rounded-xl p-4 cursor-pointer card-hover"
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <h3 className="text-lg font-semibold text-primary line-clamp-1 flex-1">
          {note.title || 'Untitled'}
        </h3>
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1 rounded hover:bg-bg-secondary text-text-secondary hover:text-primary transition-colors"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowMenu(false)}
              />
              <div className="absolute right-0 mt-1 w-40 bg-bg-card border border-border rounded-lg shadow-lg z-20 py-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(note._id);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-bg-secondary"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onShare(note._id);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-bg-secondary"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(note._id);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-danger hover:bg-bg-secondary"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Excerpt */}
      <p className="text-text-secondary text-sm line-clamp-2 mb-4">
        {excerpt || 'No content'}
      </p>

      {/* Tags */}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {tags.slice(0, 4).map((tag) => (
            <Badge key={tag} variant="accent" size="sm">
              #{tag}
            </Badge>
          ))}
          {tags.length > 4 && (
            <Badge variant="default" size="sm">+{tags.length - 4}</Badge>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between">
        {/* Collaborators */}
        <div className="flex -space-x-2">
          {collaborators.slice(0, 3).map((collab) => (
            <Avatar
              key={collab.user._id}
              src={collab.user.avatar}
              name={collab.user.name}
              size="sm"
              className="border-2 border-bg-card"
            />
          ))}
          {collaborators.length > 3 && (
            <div className="w-8 h-8 rounded-full bg-bg-secondary border-2 border-bg-card flex items-center justify-center text-xs text-text-secondary">
              +{collaborators.length - 3}
            </div>
          )}
        </div>

        {/* Timestamp */}
        <span className="text-xs text-text-secondary">
          {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
        </span>
      </div>
    </motion.div>
  );
};

export default NoteCard;
