import React from 'react';
import { Search, Plus } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import ThemeToggle from './ThemeToggle';
import UserMenu from './UserMenu';
import Input from '../ui/Input';

const Topbar = ({ searchQuery, onSearchChange, onCreateNote }) => {
  const { user } = useAuth();

  return (
    <header className="h-16 bg-bg-card border-b border-border flex items-center justify-between px-6">
      {/* Left: Search */}
      <div className="flex-1 max-w-xl">
        <Input
          type="text"
          placeholder="Search notes..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          icon={<Search className="w-5 h-5" />}
          className="bg-bg-secondary"
        />
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-4">
        <button
          onClick={onCreateNote}
          className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span className="hidden sm:inline">New Note</span>
        </button>

        <ThemeToggle />

        <UserMenu user={user} />
      </div>
    </header>
  );
};

export default Topbar;
