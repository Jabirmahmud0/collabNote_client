import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  FileText,
  Share2,
  Trash2,
  Tags,
  Plus,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { useTheme } from '../../hooks/useTheme';

const Sidebar = ({
  filter = 'all',
  onFilterChange,
  tags = [],
  onTagClick,
  selectedTag,
  onCreateNote,
}) => {
  const location = useLocation();
  const { theme } = useTheme();
  const [tagsExpanded, setTagsExpanded] = React.useState(false);

  const menuItems = [
    { id: 'all', label: 'All Notes', icon: FileText },
    { id: 'owned', label: 'My Notes', icon: FileText },
    { id: 'shared', label: 'Shared', icon: Share2 },
    { id: 'trash', label: 'Trash', icon: Trash2 },
  ];

  return (
    <aside className="w-64 bg-bg-sidebar border-r border-border flex flex-col h-full">
      {/* New Note Button */}
      <div className="p-4">
        <button
          onClick={onCreateNote}
          className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent-hover text-white py-2.5 px-4 rounded-lg font-medium transition-colors"
        >
          <Plus className="w-5 h-5" />
          New Note
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = filter === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onFilterChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-accent/10 text-accent'
                  : 'text-text-secondary hover:text-primary hover:bg-bg-secondary'
              }`}
            >
              <Icon className="w-5 h-5" />
              {item.label}
            </button>
          );
        })}

        {/* Tags Section */}
        {tags.length > 0 && (
          <div className="pt-4">
            <button
              onClick={() => setTagsExpanded(!tagsExpanded)}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-text-secondary hover:text-primary hover:bg-bg-secondary transition-colors"
            >
              {tagsExpanded ? (
                <ChevronDown className="w-5 h-5" />
              ) : (
                <ChevronRight className="w-5 h-5" />
              )}
              <Tags className="w-5 h-5" />
              Tags
            </button>

            {tagsExpanded && (
              <div className="mt-2 space-y-1 pl-8">
                {tags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => onTagClick(selectedTag === tag ? null : tag)}
                    className={`w-full text-left text-sm py-1.5 transition-colors ${
                      selectedTag === tag
                        ? 'text-accent font-medium'
                        : 'text-text-secondary hover:text-primary'
                    }`}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Footer links */}
      <div className="p-4 border-t border-border space-y-2">
        <Link
          to="/tools"
          className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            location.pathname === '/tools'
              ? 'bg-accent/10 text-accent'
              : 'text-text-secondary hover:text-primary hover:bg-bg-secondary'
          }`}
        >
          Tools
        </Link>
        <Link
          to="/profile"
          className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            location.pathname === '/profile'
              ? 'bg-accent/10 text-accent'
              : 'text-text-secondary hover:text-primary hover:bg-bg-secondary'
          }`}
        >
          Settings
        </Link>
      </div>
    </aside>
  );
};

export default Sidebar;
