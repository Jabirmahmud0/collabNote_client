import { diffLines } from 'diff';
import React from 'react';

/**
 * Compare two Quill deltas and return the diff
 */
export const compareDeltas = (delta1, delta2) => {
  const text1 = deltaToText(delta1);
  const text2 = deltaToText(delta2);

  return diffLines(text1, text2);
};

/**
 * Convert Quill delta to plain text
 */
const deltaToText = (delta) => {
  if (!delta?.ops) return '';
  return delta.ops
    .filter((op) => typeof op.insert === 'string')
    .map((op) => op.insert)
    .join('');
};

/**
 * Render diff as HTML with color coding
 */
export const renderDiff = (diffs) => {
  return diffs.map((part, index) => {
    if (part.added) {
      return React.createElement(
        'ins',
        {
          key: index,
          className: 'bg-green-200 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-0.5 rounded',
        },
        part.value
      );
    } else if (part.removed) {
      return React.createElement(
        'del',
        {
          key: index,
          className: 'bg-red-200 dark:bg-red-900/30 text-red-800 dark:text-red-300 px-0.5 rounded',
        },
        part.value
      );
    } else {
      return React.createElement('span', { key: index }, part.value);
    }
  });
};

/**
 * Get a summary of changes
 */
export const getDiffSummary = (diffs) => {
  let additions = 0;
  let deletions = 0;

  diffs.forEach((part) => {
    if (part.added) {
      additions += part.value.length;
    } else if (part.removed) {
      deletions += part.value.length;
    }
  });

  return { additions, deletions };
};

/**
 * Create a side-by-side diff view data
 */
export const createSideBySideDiff = (original, modified) => {
  const diffs = compareDeltas(original, modified);

  const originalLines = [];
  const modifiedLines = [];

  diffs.forEach((part) => {
    const lines = part.value.split('\n');

    lines.forEach((line, i) => {
      if (part.removed) {
        originalLines.push({ type: 'delete', content: line });
        if (i < lines.length - 1) originalLines.push({ type: 'newline' });
      } else if (part.added) {
        modifiedLines.push({ type: 'insert', content: line });
        if (i < lines.length - 1) modifiedLines.push({ type: 'newline' });
      } else {
        originalLines.push({ type: 'same', content: line });
        modifiedLines.push({ type: 'same', content: line });
        if (i < lines.length - 1) {
          originalLines.push({ type: 'newline' });
          modifiedLines.push({ type: 'newline' });
        }
      }
    });
  });

  return { originalLines, modifiedLines };
};
