import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../hooks/useAuth';
import { useTheme } from '../hooks/useTheme';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { User, Mail, Lock, Image, Trash2, LogOut, Sun, Moon } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Modal from '../components/ui/Modal';
import Avatar from '../components/ui/Avatar';

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  
  const [loading, setLoading] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    currentPassword: '',
    newPassword: '',
  });

  useEffect(() => {
    if (user) {
      setFormData((prev) => ({
        ...prev,
        name: user.name || '',
        email: user.email || '',
      }));
    }
  }, [user]);

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await api.patch('/api/users/me', { name: formData.name });
      updateUser({ name: formData.name });
      toast.success('Profile updated');
    } catch (error) {
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    
    if (!formData.currentPassword || !formData.newPassword) {
      toast.error('Please fill in both password fields');
      return;
    }

    setLoading(true);

    try {
      await api.patch('/api/users/me/password', {
        currentPassword: formData.currentPassword,
        newPassword: formData.newPassword,
      });
      toast.success('Password changed');
      setFormData((prev) => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
      }));
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!deletePassword) {
      toast.error('Please enter your password');
      return;
    }

    setLoading(true);

    try {
      await api.delete('/api/users/me', {
        data: { password: deletePassword },
      });
      await logout();
      navigate('/auth');
      toast.success('Account deleted');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete account');
    } finally {
      setLoading(false);
      setShowDeleteModal(false);
      setDeletePassword('');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/auth');
  };

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <header className="h-16 bg-bg-card border-b border-border flex items-center px-6">
        <h1 className="text-xl font-bold text-primary">Settings</h1>
      </header>

      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {/* Profile Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-bg-card border border-border rounded-xl p-6"
        >
          <h2 className="text-lg font-semibold text-primary mb-4">Profile</h2>
          
          <div className="flex items-center gap-4 mb-6">
            <Avatar src={user?.avatar} name={user?.name} size="xl" />
            <div>
              <button className="text-sm text-accent hover:underline">
                Change Avatar
              </button>
              <p className="text-xs text-text-secondary mt-1">
                Avatar feature coming soon
              </p>
            </div>
          </div>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <Input
              label="Name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              icon={<User className="w-5 h-5" />}
            />
            <Input
              label="Email"
              value={formData.email}
              disabled
              icon={<Mail className="w-5 h-5" />}
            />
            <Button type="submit" loading={loading}>
              Save Changes
            </Button>
          </form>
        </motion.section>

        {/* Theme Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-bg-card border border-border rounded-xl p-6"
        >
          <h2 className="text-lg font-semibold text-primary mb-4">Appearance</h2>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isDark ? <Moon className="w-5 h-5 text-text-secondary" /> : <Sun className="w-5 h-5 text-text-secondary" />}
              <div>
                <p className="text-primary font-medium">Theme</p>
                <p className="text-sm text-text-secondary">
                  Current: {isDark ? 'Dark' : 'Light'} mode
                </p>
              </div>
            </div>
            <Button variant="secondary" onClick={toggleTheme}>
              Toggle Theme
            </Button>
          </div>
        </motion.section>

        {/* Password Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-bg-card border border-border rounded-xl p-6"
        >
          <h2 className="text-lg font-semibold text-primary mb-4">Security</h2>
          
          <form onSubmit={handleChangePassword} className="space-y-4">
            <Input
              label="Current Password"
              type="password"
              value={formData.currentPassword}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, currentPassword: e.target.value }))
              }
              icon={<Lock className="w-5 h-5" />}
            />
            <Input
              label="New Password"
              type="password"
              value={formData.newPassword}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, newPassword: e.target.value }))
              }
              icon={<Lock className="w-5 h-5" />}
            />
            <Button type="submit" loading={loading}>
              Change Password
            </Button>
          </form>
        </motion.section>

        {/* Danger Zone */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-bg-card border border-danger rounded-xl p-6"
        >
          <h2 className="text-lg font-semibold text-danger mb-4">Danger Zone</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-primary font-medium">Delete Account</p>
                <p className="text-sm text-text-secondary">
                  Permanently delete your account and all data
                </p>
              </div>
              <Button
                variant="danger"
                onClick={() => setShowDeleteModal(true)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-primary font-medium">Logout</p>
                <p className="text-sm text-text-secondary">
                  Sign out of your account
                </p>
              </div>
              <Button variant="secondary" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </motion.section>
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Account"
      >
        <div className="space-y-4">
          <p className="text-text-secondary">
            This action cannot be undone. This will permanently delete your
            account and all your notes.
          </p>
          <Input
            label="Confirm Password"
            type="password"
            value={deletePassword}
            onChange={(e) => setDeletePassword(e.target.value)}
          />
          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDeleteAccount} loading={loading}>
              Delete Account
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ProfilePage;
