import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, GitCompare, Sparkles, Download } from 'lucide-react';
import MarkdownPreview from '../components/tools/MarkdownPreview';
import DiffViewer from '../components/tools/DiffViewer';
import AISummarizer from '../components/tools/AISummarizer';
import ExportPanel from '../components/tools/ExportPanel';

const ToolsPage = () => {
  const [activeTab, setActiveTab] = useState('markdown');

  const tabs = [
    {
      id: 'markdown',
      label: 'Markdown',
      icon: FileText,
      component: <MarkdownPreview />,
    },
    {
      id: 'diff',
      label: 'Diff Viewer',
      icon: GitCompare,
      component: <DiffViewer />,
    },
    {
      id: 'summary',
      label: 'AI Summary',
      icon: Sparkles,
      component: <AISummarizer />,
    },
    {
      id: 'export',
      label: 'Export',
      icon: Download,
      component: <ExportPanel />,
    },
  ];

  const activeComponent = tabs.find((tab) => tab.id === activeTab)?.component;

  return (
    <div className="h-screen flex flex-col bg-bg-primary">
      {/* Header */}
      <header className="h-16 bg-bg-card border-b border-border flex items-center px-6">
        <h1 className="text-xl font-bold text-primary">Tools</h1>
      </header>

      {/* Tab Navigation */}
      <div className="bg-bg-card border-b border-border px-6">
        <div className="flex gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-accent text-accent'
                    : 'border-transparent text-text-secondary hover:text-primary'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="h-full"
        >
          {activeComponent}
        </motion.div>
      </div>
    </div>
  );
};

export default ToolsPage;
