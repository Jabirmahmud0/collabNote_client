import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../hooks/useAuth';
import { useNotes } from '../hooks/useNotes';
import Sidebar from '../components/layout/Sidebar';
import Topbar from '../components/layout/Topbar';
import NoteList from '../components/notes/NoteList';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import toast from 'react-hot-toast';

const DashboardPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    notes,
    tags,
    loading,
    fetchNotes,
    createNote,
    deleteNote,
    permanentDelete,
    restoreNote,
  } = useNotes();

  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedNoteId, setSelectedNoteId] = useState(null);
  const [shareEmail, setShareEmail] = useState('');

  useEffect(() => {
    loadNotes();
  }, [filter, selectedTag]);

  const loadNotes = async () => {
    try {
      await fetchNotes({ filter, tag: selectedTag });
    } catch (error) {
      console.error('Failed to load notes:', error);
    }
  };

  const handleCreateNote = async () => {
    try {
      const note = await createNote({ title: 'Untitled', content: { ops: [] } });
      navigate(`/note/${note._id}`);
    } catch (error) {
      toast.error('Failed to create note');
    }
  };

  const handleNoteClick = (noteId) => {
    navigate(`/note/${noteId}`);
  };

  const handleDelete = async (noteId) => {
    const isTrash = filter === 'trash';
    const action = isTrash ? 'permanently delete' : 'delete';
    
    if (!window.confirm(`Are you sure you want to ${action} this note?`)) return;

    try {
      if (isTrash) {
        await permanentDelete(noteId);
        toast.success('Note permanently deleted');
      } else {
        await deleteNote(noteId);
        toast.success('Note moved to trash');
      }
      loadNotes();
    } catch (error) {
      toast.error('Failed to delete note');
    }
  };

  const handleRestore = async (noteId) => {
    try {
      await restoreNote(noteId);
      toast.success('Note restored');
      loadNotes();
    } catch (error) {
      toast.error('Failed to restore note');
    }
  };

  const handleShare = (noteId) => {
    setSelectedNoteId(noteId);
    setShowShareModal(true);
  };

  const handleShareSubmit = async () => {
    if (!shareEmail) {
      toast.error('Please enter an email');
      return;
    }

    try {
      // Share functionality will be implemented later
      toast.success(`Note shared with ${shareEmail}`);
      setShowShareModal(false);
      setShareEmail('');
    } catch (error) {
      toast.error('Failed to share note');
    }
  };

  const filteredNotes = notes.filter((note) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      note.title?.toLowerCase().includes(query) ||
      note.excerpt?.toLowerCase().includes(query)
    );
  });

  return (
    <div className="h-screen flex bg-bg-primary">
      {/* Sidebar */}
      <Sidebar
        filter={filter}
        onFilterChange={setFilter}
        tags={tags}
        onTagClick={setSelectedTag}
        selectedTag={selectedTag}
        onCreateNote={handleCreateNote}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Topbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onCreateNote={handleCreateNote}
        />

        <div className="flex-1 overflow-y-auto">
          <NoteList
            notes={filteredNotes}
            loading={loading}
            onNoteClick={handleNoteClick}
            onEdit={handleNoteClick}
            onShare={handleShare}
            onDelete={handleDelete}
          />
        </div>
      </div>

      {/* Share Modal */}
      <Modal
        isOpen={showShareModal}
        onClose={() => {
          setShowShareModal(false);
          setShareEmail('');
        }}
        title="Share Note"
      >
        <div className="space-y-4">
          <Input
            label="Email"
            type="email"
            placeholder="Enter collaborator's email"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
          />
          <div className="flex gap-3 justify-end">
            <Button
              variant="secondary"
              onClick={() => setShowShareModal(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleShareSubmit}>Share</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default DashboardPage;
