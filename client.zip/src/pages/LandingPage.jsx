import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Users, Sparkles, History, Github, Linkedin, Zap, Shield, Cloud } from 'lucide-react';
import Button from '../components/ui/Button';

const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Users,
      title: 'Real-time Collaboration',
      description: 'Edit notes together with multiple users simultaneously. See changes as they happen.',
      gradient: 'from-blue-500/20 to-cyan-500/20',
      iconGradient: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Sparkles,
      title: 'AI-Powered',
      description: 'Auto-summaries, smart tags, and intelligent suggestions to boost your productivity.',
      gradient: 'from-purple-500/20 to-pink-500/20',
      iconGradient: 'from-purple-500 to-pink-500',
    },
    {
      icon: History,
      title: 'Version History',
      description: 'Track changes and restore previous versions easily. Never lose your work.',
      gradient: 'from-amber-500/20 to-orange-500/20',
      iconGradient: 'from-amber-500 to-orange-500',
    },
  ];

  const additionalFeatures = [
    { icon: Zap, title: 'Lightning Fast', desc: 'Optimized for speed' },
    { icon: Shield, title: 'Secure', desc: 'End-to-end encryption' },
    { icon: Cloud, title: 'Cloud Sync', desc: 'Access anywhere' },
  ];

  return (
    <div className="min-h-screen bg-bg-primary overflow-x-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-medium text-accent bg-accent/10 rounded-full">
              ✨ Next-Gen Note Taking
            </span>
            <h1 className="text-6xl sm:text-7xl font-bold text-primary mb-6 leading-tight">
              Collaborate on Notes
              <br />
              in{' '}
              <span className="bg-gradient-to-r from-accent via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Real-time
              </span>
            </h1>
            <p className="text-xl text-text-secondary max-w-2xl mx-auto mb-10 leading-relaxed">
              A modern note-taking platform with real-time collaboration,
              AI-powered features, and seamless synchronization.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button 
                size="lg" 
                onClick={() => navigate('/auth')}
                className="shadow-lg shadow-accent/25 hover:shadow-accent/40 transition-shadow"
              >
                Get Started — It's Free
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                onClick={() => navigate('/auth')}
              >
                View Demo
              </Button>
            </div>
          </motion.div>

          {/* Hero Image / Preview */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-16"
          >
            <div className="relative mx-auto max-w-4xl">
              <div className="absolute inset-0 bg-gradient-to-r from-accent/20 via-purple-500/20 to-pink-500/20 rounded-2xl blur-2xl" />
              <div className="relative bg-bg-card border border-border rounded-2xl shadow-2xl p-2">
                <div className="bg-bg-secondary/50 rounded-xl px-4 py-3 flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                </div>
                <div className="bg-bg-primary/50 rounded-xl p-8 min-h-[200px] flex items-center justify-center">
                  <p className="text-text-secondary text-lg">Your notes, beautifully organized</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-primary mb-4">
              Everything you need
            </h2>
            <p className="text-text-secondary text-lg max-w-xl mx-auto">
              Powerful features to help you create, organize, and share your notes effortlessly.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="group relative bg-bg-card border border-border rounded-2xl p-8 hover:border-accent/50 transition-all duration-300 hover:shadow-xl hover:shadow-accent/10 hover:-translate-y-1"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                  <div className="relative">
                    <div className={`w-14 h-14 bg-gradient-to-br ${feature.iconGradient} rounded-xl flex items-center justify-center mb-6 shadow-lg`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-primary mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-text-secondary leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Additional Features */}
          <div className="grid grid-cols-3 gap-4 mt-8 max-w-3xl mx-auto">
            {additionalFeatures.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex flex-col items-center justify-center p-6 bg-bg-secondary/30 rounded-xl border border-border"
                >
                  <Icon className="w-6 h-6 text-accent mb-2" />
                  <span className="font-semibold text-primary">{item.title}</span>
                  <span className="text-sm text-text-secondary">{item.desc}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section className="py-20 px-4 bg-bg-secondary/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-primary mb-8">
            Built with Modern Technologies
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            {['React', 'Node.js', 'Socket.IO', 'MongoDB', 'Tailwind CSS', 'Gemini AI', 'Express', 'JWT'].map((tech) => (
              <span
                key={tech}
                className="px-5 py-2.5 bg-bg-card border border-border rounded-xl text-sm font-medium text-text-secondary hover:border-accent/50 hover:text-accent transition-colors cursor-default"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-accent/10 via-purple-500/10 to-pink-500/10 border border-accent/20 rounded-3xl p-12"
          >
            <h2 className="text-4xl font-bold text-primary mb-4">
              Ready to get started?
            </h2>
            <p className="text-text-secondary text-lg mb-8">
              Join thousands of users who are already collaborating in real-time.
            </p>
            <Button 
              size="lg" 
              onClick={() => navigate('/auth')}
              className="shadow-lg shadow-accent/25"
            >
              Start Collaborating Now
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-accent to-purple-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">CN</span>
              </div>
              <span className="font-semibold text-primary">CollabNote</span>
            </div>
            <p className="text-text-secondary text-sm">
              © 2024 CollabNote. Built with ❤️ by Jabir Mahmud
            </p>
            <div className="flex gap-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-text-secondary hover:text-accent transition-colors"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-text-secondary hover:text-accent transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
