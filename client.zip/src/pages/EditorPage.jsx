import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useNotes } from '../hooks/useNotes';
import { useSocket } from '../hooks/useSocket';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';
import Toolbar from '../components/editor/Toolbar';
import PresenceBar from '../components/editor/PresenceBar';
import NoteEditor from '../components/editor/NoteEditor';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { exportToPDF, exportToMarkdown, exportToJSON } from '../utils/exportUtils';

const EditorPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getNote, updateNote, shareNote } = useNotes();
  const { socket, joinRoom, leaveRoom, users } = useSocket();

  const [note, setNote] = useState(null);
  const [content, setContent] = useState({ ops: [] });
  const [title, setTitle] = useState('Untitled');
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [saveTimeout, setSaveTimeout] = useState(null);

  // Load note
  useEffect(() => {
    loadNote();
  }, [id]);

  // Join room on mount
  useEffect(() => {
    if (note && socket) {
      joinRoom(id);
    }

    return () => {
      if (id) {
        leaveRoom(id);
      }
    };
  }, [note, socket, id]);

  // Listen for remote updates
  useEffect(() => {
    if (!socket) return;

    const handleNoteUpdate = ({ delta, userId }) => {
      if (userId !== user?.id) {
        // Apply remote delta - this would need Quill's updateContents
        console.log('Remote update from:', userId);
      }
    };

    socket.on('note-update', handleNoteUpdate);

    return () => {
      socket.off('note-update', handleNoteUpdate);
    };
  }, [socket, user]);

  const loadNote = async () => {
    try {
      const noteData = await getNote(id);
      setNote(noteData);
      setTitle(noteData.title || 'Untitled');
      setContent(noteData.content || { ops: [] });
    } catch (error) {
      toast.error('Failed to load note');
      navigate('/dashboard');
    }
  };

  const handleContentChange = useCallback((delta) => {
    setContent(delta);

    // Debounced save
    if (saveTimeout) {
      clearTimeout(saveTimeout);
    }

    setIsSaving(true);
    setIsSaved(false);

    const timeout = setTimeout(async () => {
      try {
        await updateNote(id, { content: delta, saveVersion: false });
        setIsSaving(false);
        setIsSaved(true);

        // Clear saved indicator after 2 seconds
        setTimeout(() => setIsSaved(false), 2000);
      } catch (error) {
        setIsSaving(false);
        toast.error('Failed to save note');
      }
    }, 2000);

    setSaveTimeout(timeout);
  }, [id, updateNote, saveTimeout]);

  const handleTitleChange = useCallback((newTitle) => {
    setTitle(newTitle);
  }, []);

  const handleTitleBlur = async () => {
    if (title !== note?.title) {
      try {
        await updateNote(id, { title });
        toast.success('Title updated');
      } catch (error) {
        toast.error('Failed to update title');
      }
    }
  };

  const handleShare = () => {
    setShowShareModal(true);
  };

  const handleShareSubmit = async () => {
    if (!shareEmail) {
      toast.error('Please enter an email');
      return;
    }

    try {
      await shareNote(id, shareEmail, 'view');
      toast.success(`Note shared with ${shareEmail}`);
      setShowShareModal(false);
      setShareEmail('');
      loadNote();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to share note');
    }
  };

  const handleExport = async (format) => {
    try {
      switch (format) {
        case 'pdf':
          await exportToPDF(note, title);
          toast.success('PDF exported successfully');
          break;
        case 'markdown':
          await exportToMarkdown(note, title);
          toast.success('Markdown exported successfully');
          break;
        case 'json':
          await exportToJSON(note, title);
          toast.success('JSON exported successfully');
          break;
        default:
          toast.error('Unknown export format');
      }
    } catch (error) {
      toast.error('Export failed');
    }
  };

  if (!note) {
    return (
      <div className="h-screen flex items-center justify-center bg-bg-primary">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-accent" />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-bg-primary">
      {/* Toolbar */}
      <Toolbar
        title={title}
        onTitleChange={handleTitleChange}
        isSaving={isSaving}
        isSaved={isSaved}
        onShare={handleShare}
        onExport={handleExport}
      />

      {/* Presence Bar */}
      <PresenceBar users={users} />

      {/* Editor */}
      <div className="flex-1 overflow-hidden">
        <NoteEditor
          content={content}
          onChange={handleContentChange}
        />
      </div>

      {/* Share Modal */}
      <Modal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="Share Note"
      >
        <div className="space-y-4">
          <p className="text-sm text-text-secondary">
            Enter the email of the person you want to share this note with.
          </p>
          <Input
            label="Email"
            type="email"
            placeholder="collaborator@example.com"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
          />
          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowShareModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleShareSubmit}>Share</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default EditorPage;
